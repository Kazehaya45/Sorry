/* ==========================================================================
   SUBI'S APOLOGY — script.js
   Vanilla ES6. No dependencies. Everything below is wired up and functional.
   ========================================================================== */

(() => {
  'use strict';

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------ *
   * 0. UTILITIES
   * ------------------------------------------------------------------ */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
  const rand = (min, max) => Math.random() * (max - min) + min;
  const announce = (msg) => {
    const live = $('#a11y-live');
    if (live) live.textContent = msg;
  };

  /* ------------------------------------------------------------------ *
   * 1. LOADER
   * ------------------------------------------------------------------ */
  window.addEventListener('load', () => {
    const loader = $('#loader');
    setTimeout(() => {
      loader.classList.add('is-hidden');
      startRevealDelays();
    }, 1200);
  });

  // Failsafe: hide loader even if 'load' never fires quickly
  setTimeout(() => {
    const loader = $('#loader');
    if (loader && !loader.classList.contains('is-hidden')) {
      loader.classList.add('is-hidden');
      startRevealDelays();
    }
  }, 3500);

  function startRevealDelays() {
    $$('.reveal-up').forEach((el) => {
      const delay = el.dataset.delay || 0;
      el.style.setProperty('--delay', delay);
    });
  }

  /* ------------------------------------------------------------------ *
   * 2. AMBIENT BACKGROUND CANVAS
   *    Floating hearts, sparkles, and falling sakura petals — all drawn
   *    on one canvas for performance, running at a steady 60fps loop.
   * ------------------------------------------------------------------ */
  const canvas = $('#bg-canvas');
  const ctx2d = canvas.getContext('2d');
  let W, H, DPR;

  function resizeCanvas() {
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = document.documentElement.scrollHeight;
    canvas.width = W * DPR;
    canvas.height = window.innerHeight * DPR;
    canvas.style.width = W + 'px';
    canvas.style.height = window.innerHeight + 'px';
    ctx2d.setTransform(DPR, 0, 0, DPR, 0, 0);
  }
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  // Particle factories -----------------------------------------------
  class Petal {
    constructor() { this.reset(true); }
    reset(initial = false) {
      this.x = rand(0, W);
      this.y = initial ? rand(-window.innerHeight, window.innerHeight) : -20;
      this.size = rand(8, 16);
      this.speedY = rand(0.4, 1.1);
      this.speedX = rand(-0.4, 0.4);
      this.rot = rand(0, Math.PI * 2);
      this.rotSpeed = rand(-0.02, 0.02);
      this.sway = rand(0.5, 1.5);
      this.swayOffset = rand(0, Math.PI * 2);
      this.opacity = rand(0.5, 0.9);
      this.hue = rand(330, 350);
    }
    update(t) {
      this.y += this.speedY;
      this.x += this.speedX + Math.sin(t * 0.001 + this.swayOffset) * this.sway * 0.05;
      this.rot += this.rotSpeed;
      if (this.y > window.innerHeight + 20) this.reset();
    }
    draw() {
      ctx2d.save();
      ctx2d.translate(this.x, this.y);
      ctx2d.rotate(this.rot);
      ctx2d.globalAlpha = this.opacity;
      ctx2d.fillStyle = `hsl(${this.hue}, 80%, 85%)`;
      ctx2d.beginPath();
      ctx2d.ellipse(0, 0, this.size / 2, this.size / 3.2, 0, 0, Math.PI * 2);
      ctx2d.fill();
      ctx2d.restore();
    }
  }

  class Sparkle {
    constructor() { this.reset(); }
    reset() {
      this.x = rand(0, W);
      this.y = rand(0, window.innerHeight);
      this.size = rand(1.2, 2.6);
      this.baseOpacity = rand(0.3, 0.9);
      this.twinkleSpeed = rand(0.02, 0.05);
      this.phase = rand(0, Math.PI * 2);
    }
    update(t) {
      this.phase += this.twinkleSpeed;
    }
    draw() {
      const o = (Math.sin(this.phase) + 1) / 2 * this.baseOpacity;
      ctx2d.save();
      ctx2d.globalAlpha = o;
      ctx2d.fillStyle = '#FFD79A';
      ctx2d.beginPath();
      ctx2d.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx2d.fill();
      ctx2d.restore();
    }
  }

  class FloatingHeart {
    constructor() { this.reset(true); }
    reset(initial = false) {
      this.x = rand(0, W);
      this.y = initial ? rand(0, window.innerHeight) : window.innerHeight + 20;
      this.size = rand(6, 12);
      this.speed = rand(0.25, 0.6);
      this.sway = rand(0.3, 0.8);
      this.swayOffset = rand(0, Math.PI * 2);
      this.opacity = rand(0.15, 0.4);
    }
    update(t) {
      this.y -= this.speed;
      this.x += Math.sin(t * 0.0012 + this.swayOffset) * this.sway * 0.06;
      if (this.y < -20) this.reset();
    }
    draw() {
      ctx2d.save();
      ctx2d.globalAlpha = this.opacity;
      ctx2d.fillStyle = '#F2A6B0';
      const s = this.size;
      ctx2d.translate(this.x, this.y);
      ctx2d.beginPath();
      ctx2d.moveTo(0, s * 0.3);
      ctx2d.bezierCurveTo(-s, -s * 0.6, -s * 1.6, s * 0.5, 0, s * 1.4);
      ctx2d.bezierCurveTo(s * 1.6, s * 0.5, s, -s * 0.6, 0, s * 0.3);
      ctx2d.fill();
      ctx2d.restore();
    }
  }

  const petalCount = window.innerWidth < 600 ? 14 : 26;
  const sparkleCount = window.innerWidth < 600 ? 30 : 55;
  const heartCount = window.innerWidth < 600 ? 8 : 14;

  const petals = Array.from({ length: petalCount }, () => new Petal());
  const sparkles = Array.from({ length: sparkleCount }, () => new Sparkle());
  const hearts = Array.from({ length: heartCount }, () => new FloatingHeart());

  let rafId;
  function animateBackground(t) {
    ctx2d.clearRect(0, 0, W, window.innerHeight);
    sparkles.forEach((s) => { s.update(t); s.draw(); });
    hearts.forEach((h) => { h.update(t); h.draw(); });
    petals.forEach((p) => { p.update(t); p.draw(); });
    rafId = requestAnimationFrame(animateBackground);
  }

  if (!reduceMotion) {
    requestAnimationFrame(animateBackground);
  } else {
    // Draw a single static frame for reduced-motion users
    ctx2d.clearRect(0, 0, W, window.innerHeight);
    sparkles.forEach((s) => s.draw());
    hearts.forEach((h) => h.draw());
    petals.forEach((p) => p.draw());
  }

  /* ------------------------------------------------------------------ *
   * 3. CURSOR GLOW (mouse-follow light)
   * ------------------------------------------------------------------ */
  const glow = $('#cursor-glow');
  let glowX = window.innerWidth / 2, glowY = window.innerHeight / 2;
  let targetX = glowX, targetY = glowY;

  window.addEventListener('pointermove', (e) => {
    targetX = e.clientX;
    targetY = e.clientY;
  });

  function animateGlow() {
    glowX += (targetX - glowX) * 0.12;
    glowY += (targetY - glowY) * 0.12;
    glow.style.transform = `translate(${glowX}px, ${glowY}px) translate(-50%,-50%)`;
    requestAnimationFrame(animateGlow);
  }
  if (!reduceMotion && window.matchMedia('(hover:hover)').matches) {
    requestAnimationFrame(animateGlow);
  }

  /* ------------------------------------------------------------------ *
   * 4. CLICK RIPPLE EFFECT
   * ------------------------------------------------------------------ */
  document.addEventListener('click', (e) => {
    const ripple = document.createElement('div');
    ripple.className = 'ripple';
    const size = 140;
    ripple.style.width = size + 'px';
    ripple.style.height = size + 'px';
    ripple.style.left = e.clientX + 'px';
    ripple.style.top = e.clientY + 'px';
    document.body.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
  });

  /* ------------------------------------------------------------------ *
   * 5. ENVELOPE OPEN -> SCROLL TO LETTER
   * ------------------------------------------------------------------ */
  const envelopeBtn = $('#envelope-btn');
  const openHeartBtn = $('#open-heart-btn');
  const letterSection = $('#letter');
  const letterPaper = $('#letter-paper');

  let journeyStarted = false;

  function beginJourney() {
    if (journeyStarted) {
      letterSection.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' });
      return;
    }
    journeyStarted = true;
    envelopeBtn.classList.add('is-open');
    envelopeBtn.setAttribute('aria-label', 'Envelope opened');
    spawnConfetti(26);
    announce('Envelope opened. Scrolling to the letter.');

    setTimeout(() => {
      letterSection.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' });
      setTimeout(() => {
        letterPaper.classList.add('is-unfolded');
        setTimeout(startTypewriter, reduceMotion ? 0 : 700);
      }, 400);
    }, 500);
  }

  envelopeBtn.addEventListener('click', beginJourney);
  openHeartBtn.addEventListener('click', beginJourney);

  /* ------------------------------------------------------------------ *
   * 6. TYPEWRITER EFFECT FOR THE LETTER
   * ------------------------------------------------------------------ */
  const typewriterText =
    "I've been meaning to write this for a while, and I kept putting it off " +
    "because it's hard to say out loud. So I'm saying it here instead, slowly, " +
    "and honestly. This isn't complicated — I just want to say I'm sorry, " +
    "clearly and without any conditions attached to it.";

  let typewriterDone = false;

  function startTypewriter() {
    if (typewriterDone) return;
    const el = $('#typewriter-1');
    const cursor = $('#tw-cursor-1');

    if (reduceMotion) {
      el.textContent = typewriterText;
      typewriterDone = true;
      cursor.style.display = 'none';
      return;
    }

    let i = 0;
    const speed = 22; // ms per character
    function type() {
      if (i <= typewriterText.length) {
        el.textContent = typewriterText.slice(0, i);
        i++;
        setTimeout(type, speed);
      } else {
        typewriterDone = true;
        cursor.style.animation = 'blink 0.9s steps(1) infinite';
      }
    }
    type();
  }

  // Also trigger typewriter if the user scrolls to the letter manually
  const letterObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        letterPaper.classList.add('is-unfolded');
        setTimeout(startTypewriter, 500);
      }
    });
  }, { threshold: 0.4 });
  letterObserver.observe(letterSection);

  /* ------------------------------------------------------------------ *
   * 7. SCROLL-TRIGGERED REVEAL ANIMATIONS
   * ------------------------------------------------------------------ */
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2, rootMargin: '0px 0px -60px 0px' });

  $$('.scroll-reveal').forEach((el) => revealObserver.observe(el));

  /* ------------------------------------------------------------------ *
   * 8. INTERACTIVE APOLOGY CARDS (flip on tap, one at a time)
   * ------------------------------------------------------------------ */
  $$('.a-card').forEach((card) => {
    card.addEventListener('click', () => {
      const wasFlipped = card.classList.contains('is-flipped');
      card.classList.toggle('is-flipped');
      card.setAttribute('aria-pressed', String(!wasFlipped));
      if (!wasFlipped) {
        spawnConfetti(6, card.getBoundingClientRect());
      }
    });
  });

  /* ------------------------------------------------------------------ *
   * 9. FIREFLY JAR — generated fireflies inside the SVG jar
   * ------------------------------------------------------------------ */
  const jarFireflies = $('#jar-fireflies');
  const jarFireflyCount = 7;
  for (let i = 0; i < jarFireflyCount; i++) {
    const f = document.createElement('span');
    f.className = 'firefly';
    f.style.left = rand(20, 80) + '%';
    f.style.top = rand(30, 80) + '%';
    f.style.animationDuration = rand(3, 6) + 's';
    f.style.animationDelay = rand(0, 4) + 's';
    jarFireflies.appendChild(f);
  }

  /* ------------------------------------------------------------------ *
   * 10. CONFETTI BURST
   * ------------------------------------------------------------------ */
  const confettiColors = ['#F2A6B0', '#FFD79A', '#BDEAE0', '#FBD8E3', '#FFF8F3'];

  function spawnConfetti(count = 20, originRect = null) {
    if (reduceMotion) return;
    const originX = originRect ? originRect.left + originRect.width / 2 : window.innerWidth / 2;
    const originY = originRect ? originRect.top + originRect.height / 2 : window.innerHeight * 0.25;

    for (let i = 0; i < count; i++) {
      const piece = document.createElement('div');
      piece.className = 'confetti-piece';
      const size = rand(6, 11);
      piece.style.width = size + 'px';
      piece.style.height = size * rand(0.6, 1) + 'px';
      piece.style.background = confettiColors[Math.floor(rand(0, confettiColors.length))];
      piece.style.left = (originX + rand(-60, 60)) + 'px';
      piece.style.top = originY + 'px';
      piece.style.animationDuration = rand(1.6, 2.8) + 's';
      piece.style.opacity = rand(0.7, 1);
      document.body.appendChild(piece);
      piece.addEventListener('animationend', () => piece.remove());
    }
  }

  /* ------------------------------------------------------------------ *
   * 11. REPLAY BUTTON — smoothly returns to the top
   * ------------------------------------------------------------------ */
  const replayBtn = $('#replay-btn');
  replayBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    announce('Returned to the beginning of the letter.');
  });

  /* ------------------------------------------------------------------ *
   * 12. RESIZE HANDLING FOR SCROLL HEIGHT CHANGES (canvas height sync)
   * ------------------------------------------------------------------ */
  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(resizeCanvas, 200);
  });

  /* ------------------------------------------------------------------ *
   * 13. INITIAL A11Y STATE FOR CARDS
   * ------------------------------------------------------------------ */
  $$('.a-card').forEach((card) => card.setAttribute('aria-pressed', 'false'));

})();
